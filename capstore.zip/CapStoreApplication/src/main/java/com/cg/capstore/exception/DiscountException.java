package com.cg.capstore.exception;

public class DiscountException {

}
