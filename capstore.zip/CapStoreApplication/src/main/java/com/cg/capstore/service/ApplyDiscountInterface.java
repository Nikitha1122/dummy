package com.cg.capstore.service;

import com.cg.capstore.beans.ProductBean;

public interface ApplyDiscountInterface {
	public String Discount(String pid);

}
